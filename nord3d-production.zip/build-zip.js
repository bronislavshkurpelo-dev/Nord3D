const { execSync } = require('child_process');
const fs = require('fs');

const zipDest = 'C:/Users/brono/.gemini/antigravity/brain/af3705fc-cd3d-45a7-a734-7b8af975951a/nord3d-production.zip';
const localDest = 'C:/Users/brono/.gemini/antigravity/scratch/norilsk-3d-print/nord3d-production.zip';

if (fs.existsSync(zipDest)) fs.unlinkSync(zipDest);
if (fs.existsSync(localDest)) fs.unlinkSync(localDest);

process.chdir('C:/Users/brono/.gemini/antigravity/scratch/norilsk-3d-print');
execSync(`tar.exe -a -c -f "${zipDest}" --exclude="node_modules" --exclude=".git" --exclude="*.zip" --exclude="audit-screenshots" *`);
fs.copyFileSync(zipDest, localDest);

const stat = fs.statSync(zipDest);
console.log('Archive created successfully:', zipDest, 'Size:', (stat.size / 1024 / 1024).toFixed(2), 'MB');
