const { execSync } = require('child_process');
const fs = require('fs');

const srcDir = 'C:/Users/brono/.gemini/antigravity/scratch/norilsk-3d-print';
const destZip = 'C:/Users/brono/.gemini/antigravity/brain/af3705fc-cd3d-45a7-a734-7b8af975951a/nord3d-production.zip';
const localZip = 'C:/Users/brono/.gemini/antigravity/scratch/norilsk-3d-print/nord3d-production.zip';

if (fs.existsSync(destZip)) fs.unlinkSync(destZip);
if (fs.existsSync(localZip)) fs.unlinkSync(localZip);

execSync(`tar.exe -a -c -f "${destZip}" --exclude="*.zip" --exclude="node_modules" --exclude="audit-screenshots" --exclude="audit-results.json" --exclude="run-mobile-audit.js" *`, {
  cwd: srcDir,
  stdio: 'inherit'
});

fs.copyFileSync(destZip, localZip);
const stat = fs.statSync(destZip);
console.log(`Rebuilt ${destZip}: ${(stat.size / 1024 / 1024).toFixed(2)} MB`);
